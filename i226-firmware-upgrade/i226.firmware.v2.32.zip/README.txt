I226-V
Use 1MB bin file
Reference: https://github.com/BillyCurtis/Intel-i226-V-NVM-Firmware?tab=readme-ov-file#readme
Thanks to Billy Curtis for chiming in on OPNsense forum (https://forum.opnsense.org/index.php?topic=48695)

This README with the util and 1MB 2.32 bin can be obtained from:
https://intel226bucket.s3.us-east-1.amazonaws.com/i226.zip
1) This README file
2) Billy Curtis i226-V v2.32 1MB bin
3) Example nvm.cfg file
4) nvmupdate64e util from the Intel 34.0 download bundle
5) Intel doc on using nvmupdate64e


This section w/o the hashes is the nvm.cfg file, modify for your hardware.
This same cfg is included in the zip as "nvm.cfg" that you modify as needed.
#########################
CURRENT FAMILY: 1.0.0
CONFIG VERSION: 1.20.0

; NIC device
BEGIN DEVICE
DEVICENAME: Intel(R) Ethernet Controller I226-V
VENDOR: 8086
DEVICE: 125C
SUBVENDOR: 8086
SUBDEVICE: 0000
NVM IMAGE: FXVL_125C_V_1MB_2.32.bin
EEPID: 80000425
RESET TYPE: REBOOT
REPLACES: 80000308
END DEVICE
##########################

Util Reference: http://tmei-net.com/technology-sharing/how-do-use-intel-ethernet-nvm-update-tool.html
The util command targets a specific device by MAC address.
./nvmupdate64e -b -l nvm.log -m 00E0B468DCBC -f -u -c nvm.cfg